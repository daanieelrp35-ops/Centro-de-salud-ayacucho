# Sitio web · Grupo Salud Integral Ayacucho

Sitio estático (HTML + CSS + JavaScript). No necesita instalar nada ni base de datos, y funciona directo en GitHub Pages.

## Estructura

```
index.html            Estructura base (no se toca)
css/estilos.css       Diseño
js/datos.js           ← Especialidades, profesionales, horarios, teléfonos
js/blog-datos.js      ← Notas del blog (se agrega una por mes)
js/app.js             Lógica de la página (no se toca)
```

## Cómo verlo en tu computadora

Hacé doble clic en `index.html`. Necesita internet para cargar las tipografías y las fotos.

## Cómo publicarlo en GitHub Pages

1. Entrá al repositorio `oficial` de la cuenta `grupo-salud-integral-ayacucho`.
2. Subí (o reemplazá) estos archivos respetando las carpetas: `index.html`, `css/`, `js/`.
3. Guardá los cambios ("Commit"). En uno o dos minutos ya está online.

> Las fotos de la web actual se siguen cargando desde la misma dirección
> (`imgBase` en `js/datos.js`). Si preferís tenerlas dentro de esta carpeta,
> copialas a `img/` y cambiá `imgBase` por `"img/"`.

## Cómo completar horarios y turnos de un profesional

Abrí `js/datos.js`, buscá al profesional y completá los campos vacíos:

```js
horarios: [
  { dias: "Lunes y miércoles", horas: "16:00 a 20:00" },
  { dias: "Viernes", horas: "09:00 a 12:00", nota: "Solo con turno previo" }
],
turnos: "Turnos por WhatsApp de lunes a viernes de 9 a 18 h.",
obrasSociales: ["OSDE", "Swiss Medical", "Particulares"],
modalidad: "Presencial",
notas: "Traer estudios anteriores.",
frase: "Una frase de presentación.",
redes: { instagram: "https://instagram.com/usuario" },
```

Lo que dejes vacío no rompe nada: la página muestra "consultar al pedir el turno".

## Cómo agregar una nota al blog (una vez por mes)

1. Abrí `js/blog-datos.js`.
2. Copiá la plantilla que está comentada al principio y pegala debajo de `const BLOG_POSTS = [`.
3. Completá `fecha` (por ejemplo `"2026-10"`), título, autor, resumen y el texto en `contenido`.
4. Guardá y subí el archivo. La nota aparece sola, agrupada por mes, con su filtro por categoría.

## Cómo agregar una especialidad o un profesional nuevo

En `js/datos.js`, copiá un bloque completo de especialidad (o de profesional dentro de `profesionales`), pegalo y cambiá los datos. Aparece automáticamente en el listado, en el buscador y con su propia página.

## Notas

- Las direcciones de la página son del estilo `.../#/blog` y `.../#/especialidad/nutricion`. Así funciona en GitHub Pages sin configuración extra.
- El botón de WhatsApp usa el mismo número de teléfono del profesional. Si el número que figura no tiene WhatsApp, agregá el campo `whatsapp: "351 ..."` con otro.
