/* =====================================================================
   BLOG · NOTAS DEL MES
   ---------------------------------------------------------------------
   PARA AGREGAR UNA NOTA NUEVA:
   1. Copiá una nota completa (desde la llave "{" hasta "}," inclusive).
   2. Pegala al principio de la lista, justo debajo de "const BLOG_POSTS = [".
   3. Cambiá los datos. El orden no importa: la página las ordena sola
      por fecha, de la más nueva a la más vieja.

   CAMPOS
   id            Único, sin espacios ni tildes. Ej: "diabetes-2026-10"
   fecha         "AAAA-MM" (mes) o "AAAA-MM-DD" (día). Ej: "2026-10"
   categoria     "Noticias del mes", "Nutrición", "Psicopedagogía", etc.
                 Se crean solas los filtros con las categorías que uses.
   titulo        Título de la nota.
   autor         Quién la escribe (opcional).
   resumen       Una o dos frases que aparecen en el listado.
   imagen        Nombre del archivo de imagen (opcional).
   especialidad  id de una especialidad de datos.js (opcional). Agrega un
                 botón para ir a los datos del profesional.
   contenido     El texto, escrito entre `comillas invertidas` usando
                 estas etiquetas simples:
                   <p>Un párrafo.</p>
                   <h3>Un subtítulo</h3>
                   <ul><li>Un ítem de lista</li></ul>
                   <strong>negrita</strong>   <em>cursiva</em>
                   <a href="https://...">un enlace</a>
   ===================================================================== */

const BLOG_POSTS = [

  /* ---------- PLANTILLA (copiá desde acá) ----------
  {
    id: "titulo-corto-2026-10",
    fecha: "2026-10",
    categoria: "Noticias del mes",
    titulo: "Título de la nota",
    autor: "Nombre del profesional",
    resumen: "Una o dos frases para el listado.",
    imagen: "",
    especialidad: "",
    contenido: `
      <p>Primer párrafo.</p>
      <h3>Subtítulo</h3>
      <p>Segundo párrafo.</p>
    `
  },
  ---------- hasta acá ---------- */

  {
    id: "hantavirus-2026-05",
    fecha: "2026-05",
    categoria: "Noticias del mes",
    titulo: "Hantavirus: qué es real y qué es exageración",
    autor: "Lucena Bustos",
    resumen: "Se habla mucho del hantavirus en redes y medios. Repasamos qué está pasando, si es “la próxima pandemia”, sus síntomas y qué recomiendan los especialistas.",
    imagen: "ChatGPT Image 11 may 2026, 22_35_07.png",
    especialidad: "",
    contenido: `
      <p>En estos días, el virus del que más se está hablando en redes y medios es el hantavirus, especialmente por un brote ocurrido en el crucero MV Hondius y por el aumento de casos registrados en Argentina durante 2026. Lo importante es separar los hechos reales de la exageración y los rumores.</p>

      <h3>¿Qué está pasando realmente?</h3>
      <p>Las autoridades sanitarias confirmaron un brote de hantavirus asociado a un crucero internacional que había partido desde Sudamérica. Hasta ahora se investigaron varios contagios y algunas muertes vinculadas al caso. Estudios genéticos recientes indican que la variante involucrada sería la llamada “Andes”, conocida desde hace años en Argentina y Chile. (El País)</p>
      <p>Además, Argentina reportó más casos este año que en temporadas anteriores, con cifras oficialmente por encima del “umbral de brote” epidemiológico. (EFE Noticias) El hantavirus existe desde hace décadas y en Argentina se conoce especialmente en zonas rurales o de montaña. Se transmite principalmente por contacto con excremento, orina o saliva de roedores infectados.</p>
      <p>La variante Andes es una de las pocas cepas del mundo que puede transmitirse entre personas, aunque esto suele requerir contacto cercano y prolongado. (El País)</p>

      <h3>¿Es “la próxima pandemia”?</h3>
      <p>Por ahora, no hay evidencia de eso. La Organización Mundial de la Salud aclaró públicamente que la situación no se parece al COVID-19 y que el riesgo de pandemia global es bajo. El virus no tiene la misma facilidad de transmisión aérea masiva que el coronavirus. (El Territorio)</p>
      <p>Lo que sí preocupa a los especialistas es el aumento de casos en ciertas regiones, la capacidad de contagio humano de la variante Andes y la necesidad de vigilancia epidemiológica.</p>

      <h3>¿Por qué explotó en redes sociales?</h3>
      <p>Porque se mezclaron noticias reales con teorías conspirativas, videos fuera de contexto, información falsa y comparaciones exageradas con el COVID. Muchos contenidos virales afirman cosas que no están confirmadas, como mutaciones “apocalípticas”, encubrimientos o contagios instantáneos. Varias de esas publicaciones ya fueron desmentidas. (Cadena SER)</p>

      <h3>Síntomas principales del hantavirus</h3>
      <ul>
        <li>Fiebre</li>
        <li>Dolor muscular</li>
        <li>Cansancio intenso</li>
        <li>Dolor de cabeza</li>
        <li>Náuseas</li>
      </ul>
      <p>En casos graves puede afectar rápidamente los pulmones y dificultar la respiración, por eso requiere atención médica urgente.</p>

      <h3>Qué recomiendan los especialistas</h3>
      <p>Sin entrar en paranoia, las recomendaciones actuales son evitar el contacto con roedores y sus excrementos, ventilar los espacios cerrados antes de limpiarlos, no barrer en seco lugares con posible presencia de ratones y consultar rápido si aparecen síntomas fuertes tras una exposición en zonas de riesgo.</p>
      <p><em>Redactado por Lucena Bustos, fuentes mencionadas.</em></p>
    `
  },

  {
    id: "psicomotricidad-2026-05",
    fecha: "2026-05",
    categoria: "Psicomotricidad",
    titulo: "Psicomotricidad",
    autor: "Belén Gallo",
    resumen: "Material informativo sobre psicomotricidad, brindado por Belén Gallo (MP 12901).",
    imagen: "WhatsApp Image 2026-05-08 at 11.32.52.jpeg",
    especialidad: "",
    contenido: `
      <p><em>Información brindada por Belén Gallo, MP 12901.</em></p>
    `
  },

  {
    id: "reacciones-solares-2025-11",
    fecha: "2025-11",
    categoria: "Medicina general",
    titulo: "Reacciones solares: cómo cuidarte del sol",
    autor: "Efraín Bustos, médico cirujano (MP 7376)",
    resumen: "Qué son los rayos ultravioletas, cuándo evitar el sol, cómo elegir el protector y cuáles son los peligros de la exposición desmedida.",
    imagen: "",
    especialidad: "ninez",
    contenido: `
      <p class="destacado">Se aconseja imprimir y coleccionar.</p>

      <p>Los rayos ultravioletas (UV) son los responsables del enrojecimiento, las quemaduras y el envejecimiento de la piel. Esto sucede no solo cuando se está expuesto al sol, sino también cuando está nublado, porque las nubes dejan pasar el 85 % de estos rayos. Entre las 10 y las 16 horas es el período en que se debe evitar tomar sol, ya que es la etapa en la que más se manifiesta el rigor de estos rayos. La intensidad de la radiación depende de la latitud donde uno se encuentra, la nubosidad existente, la altitud de la superficie, el ozono y la reflexión por la superficie, que también debe tenerse en cuenta.</p>
      <p>Esta última incrementa la acción de los rayos directos en la siguiente proporción: nieve 85 %, arena 17 %, agua 5 % (efecto lupa), césped 3 % y asfalto 2 %. La protección natural del ser humano está dada por el tipo de piel: los albinos, rubios y pelirrojos tienen muy poca capacidad de tolerancia a la radiación solar, al igual que los bebés menores de 1 año. Los castaños y trigueños tienen resistencia normal y los de piel oscura son los de mayor tolerancia. Durante el embarazo se debe tener mucha precaución, pues las manchas en la cara (cloasma) se fijan y no desaparecen. Los lactantes pueden tomar sol antes de las 10 h y después de las 17 h, alrededor de 5 minutos en el cuerpo (excepto en la cabeza).</p>

      <h3>El bronceado</h3>
      <p>El bronceado es un mecanismo de defensa de la piel, ya que ejerce un efecto de filtrado de rayos UV. Este mecanismo, que se busca por estética personal, debe realizarse en forma metódica. Si se desea conseguir este efecto, debe comenzarse con 10 minutos de exposición e ir aumentando 10 minutos por día. Al décimo día la piel estará preparada para soportar la acción del sol sin mayores problemas, excepto por el cúmulo de radiación solar, que sobrepasa toda defensa y predispone al cáncer de piel.</p>

      <h3>Protectores solares</h3>
      <p>El uso de factores de protección solar es muy importante, principalmente para los de piel más blanca. Como ejemplo, un factor 20 permite exponerse al sol 20 minutos como si fuera un minuto sin protección. De todas maneras, desde un punto de vista práctico deben colocarse cada 2 horas, porque pierden su poder y se escurren con el agua y la transpiración. Es importante no colocarse ninguna otra sustancia (cremas, vegetales, lociones, etc.) excepto el filtro o pantalla solar.</p>

      <h3>Peligros</h3>
      <ol type="a">
        <li>La insolación es una deshidratación con peligro de vida causada por los rayos infrarrojos.</li>
        <li>El agotamiento por calor se produce después de varios días.</li>
        <li>Los calambres por falta de minerales también son frecuentes.</li>
        <li>La quemadura solar, producida por los rayos UVB.</li>
        <li>El envejecimiento de la piel, producido por casi todos los rayos.</li>
        <li>El cáncer de piel.</li>
        <li>La lucitis o dermatitis producida por el sol, también llamadas reacciones de fotosensibilidad. Se pueden evitar consultando con el médico, porque son producidas por ciertos medicamentos en presencia de rayos solares. Las reacciones fotoalérgicas se generan porque la droga ingerida o colocada en la piel es convertida (por acción del sol) en un producto alergénico y produce, a los pocos minutos, una reacción de tipo urticaria, o lesiones después de las 24 horas de tipo eczemas o pápulas. También se encuentran las reacciones fototóxicas: no se producen mientras no haya exposición al sol, pero pueden provocarse, por ejemplo, durante un tratamiento con tetraciclinas, sulfonamidas, clorpromazina, etc. Hay enfermedades que se agravan con la acción del sol, como el lupus, el herpes simple, la rosácea, las porfirias, etc.</li>
        <li>El más grave peligro es el golpe de calor: un cuadro con temperatura mayor de 40 grados, con exposición al calor con esfuerzo o sin él, y disfunción neurológica, que lleva al shock y a la deshidratación.</li>
      </ol>

      <h3>Consejos</h3>
      <p>Beber agua o líquidos frutales en abundancia, limitar la actividad física, usar sombreros y lentes protectores, descansar en la sombra y usar ropas de color blanco, pues son más frescas al rechazar los rayos solares.</p>
      <p>El sol es imprescindible para la existencia de la vida y nos proporciona la vitamina D, pero las exposiciones desmedidas pueden traer consecuencias graves. Si tenés algún síntoma después de tomar sol, principalmente los niños, los ancianos o quienes toman medicamentos, no demores en consultar con el médico. Puede correr peligro de vida.</p>

      <details>
        <summary>Explicativo: radiaciones solares y capa de ozono</summary>
        <p>El nanómetro (nm) es una medida de longitud usada para medir las radiaciones solares y equivale a la milmillonésima parte del metro, o sea 10 a la menos nueve. La luz solar está compuesta por un espectro continuo de radiaciones electromagnéticas cuya longitud de onda va desde menos de 10 nm hasta los 1500 nm. Menos de 10 nm son los rayos cósmicos, como los rayos gamma y los rayos X. De 10 a 400 nm están los rayos ultravioletas (UV): los UVA de 315 a 400 nm, los UVB de 280 a 315 nm y los UVC de 100 a 280 nm. Entre 400 y 780 nm están los rayos de luz visible, que dan los colores, y de 780 a 1500 nm los rayos infrarrojos, que dan calor.</p>
        <p>La atmósfera es la envoltura gaseosa que rodea a la Tierra y está formada por una serie de capas de distintas características en cuanto a su composición y comportamiento. La atmósfera inferior, la más cercana a la Tierra, está compuesta por dos capas: la tropósfera, hasta los 15.000 metros, y la estratósfera, desde los 15.000 hasta los 50.000 metros. Esta última tiene una función fundamental de filtro e incluye la capa de ozono, que absorbe casi la totalidad de los UVC, parte de los UVB y casi nada de los UVA.</p>
        <p>La luz, en relación con los cuerpos que la reciben, puede ser reflejada, transmitida o absorbida. Solo la luz absorbida desarrolla su efecto fotobiológico, y estos efectos se realizan sobre un cromóforo, que es una molécula capaz de absorber la luz; el cromóforo principal es el sistema oxígeno-ozono. La llamada capa de ozono no es una verdadera capa, ya que el ozono está disperso en la inmensidad de la estratósfera en proporciones muy pequeñas (10 partes por millón) y está sujeto a componerse y descomponerse continuamente. Sus principales destructores serían los compuestos halogenados, dentro de ellos los clorofluorocarbonados: cadenas cortas de carbono que contienen flúor y cloro, con una vida media de 75 a 120 años, durante la cual un solo radical de cloro destruye 100.000 moléculas de ozono. Actualmente la industria ha reducido de forma drástica estos compuestos, utilizados como propelentes de sprays y en refrigeración, sustituyéndolos por otros gases.</p>
      </details>
    `
  },

  {
    id: "cambios-epigeneticos-2025-11",
    fecha: "2025-11",
    categoria: "Medicina general",
    titulo: "Cambios epigenéticos: cómo influye el ambiente en tu salud",
    autor: "Efraín Bustos, médico cirujano (MP 7376) y especialista en pediatría (MP 2219)",
    resumen: "Qué son los cambios epigenéticos, qué factores los influyen, qué enfermedades se relacionan con ellos y qué hábitos ayudan a cuidarte.",
    imagen: "",
    especialidad: "ninez",
    contenido: `
      <p class="destacado">Se aconseja imprimir y coleccionar.</p>

      <p>Son alteraciones en la función de los genes que no implican cambios en la secuencia del ADN subyacente, pero que pueden ser heredables y afectar la forma en que se expresan los genes. Estos cambios pueden ser influenciados por factores ambientales y pueden tener consecuencias para la salud y el desarrollo. En lugar de cambiar el código del ADN, los cambios epigenéticos modifican cómo se lee e interpreta ese código.</p>
      <p>Pueden ser influenciados por factores ambientales como la dieta, el estrés, la exposición a toxinas y el ejercicio. Pueden ser heredados a través de las generaciones, lo que significa que los factores ambientales pueden tener efectos a largo plazo en la salud y el desarrollo.</p>

      <h3>Medio ambiente desfavorable</h3>
      <ul>
        <li>Rayos ultravioletas</li>
        <li>Ondas electromagnéticas</li>
        <li>Drogas y alcohol</li>
        <li>Disruptores hormonales</li>
        <li>Estrés crónico</li>
        <li>Falta de cuidado en la primera infancia</li>
        <li>Relaciones entre personas tóxicas</li>
        <li>Actitud pesimista</li>
        <li>Alimentación rica en productos procesados</li>
      </ul>

      <h3>Enfermedades por factores epigenéticos</h3>
      <p>Cardiovasculares, metabólicas, obesidad, autoinmunes, inflamatorias, cáncer, diabetes, enfermedad del hígado graso no alcohólico, osteoporosis, gota, hipertiroidismo, hipotiroidismo y otras.</p>

      <h3>Alimentos recomendados</h3>
      <p>Brócoli, té verde, cúrcuma, legumbres, frutos secos, semillas, hojas verdes y pescado azul.</p>

      <h3>Los telómeros y el envejecimiento celular</h3>
      <p>Si bien contra la genética no podemos hacer modificaciones, podemos apuntar a ser la mejor versión de nosotros mismos; la ciencia y nuestros telómeros lo confirman. El envejecimiento celular se puede medir identificando la longitud de los telómeros: regiones del ADN que se encuentran en los extremos de los cromosomas en las células circulantes.</p>
      <p>Al dividirse las células, se copian sus cromosomas y, en este proceso, se pierde una pequeña parte del ADN del telómero cada vez que se realiza la división, acortando la secuencia. Cuando la longitud del telómero se acorta demasiado, la célula ya no puede dividirse y se da el proceso conocido como senescencia o apoptosis (muerte celular).</p>

      <h3>Nutrientes con posible efecto sobre la longitud telomérica (más largo, mejor)</h3>
      <ul>
        <li><strong>Vitamina B9 o folato:</strong> hígado, leche, vegetales de hoja.</li>
        <li><strong>Vitamina B12 o cobalamina:</strong> carnes, aves, huevos, lácteos, quesos fermentados, alimentos de origen animal, legumbres y vegetales.</li>
        <li><strong>Vitaminas B3 (niacina), A y D:</strong> leche entera, manteca, crema, queso, hígado, huevo, pescados grasos. Vegetales: hojas verdes, zanahoria, zapallo, batata, frutas amarillas y rojas, perejil. Huevos, lácteos fortificados, aceite de pescado, hongos, levadura.</li>
        <li><strong>Vitaminas E y C:</strong> la E en aceites vegetales, frutos secos y semillas; la C en kiwi, frutillas, ajíes, tomate y cítricos.</li>
        <li><strong>Magnesio, zinc, selenio, omega 3, polifenoles, curcumina y coenzima Q10:</strong> semillas, nueces, cereales integrales, vegetales verdes y alimentos no procesados.</li>
      </ul>
      <p>Otras fuentes mencionadas: vegetales (según el suelo); de origen animal, carne, leche, pescados y mariscos; cereales integrales; frutos secos y semillas; pescados grasos y otros mariscos; nueces, semillas de lino y de chía; aceite de lino, soja y canola; manzanas, cítricos, uvas, frutillas, frambuesas, granada, arándanos, berenjena, remolacha, tomate, cebolla, ajo, pimientos, brócoli, espinaca, legumbres, soja, trigo y otros cereales integrales; mate, té (verde, negro, blanco), cacao y vino tinto (en forma moderada). Raíz de cúrcuma; carnes, pescados y frutos secos en bajas cantidades.</p>

      <h3>Recomendaciones</h3>
      <ul>
        <li>Comer la cantidad adecuada para prevenir la obesidad.</li>
        <li>Hacer actividad física.</li>
        <li>Evitar fumar y el consumo excesivo de alcohol.</li>
        <li>Evitar las bebidas azucaradas.</li>
        <li>Evitar los alimentos ultraprocesados.</li>
        <li>Evitar los disruptores endocrinos (plásticos y alimentos fumigados).</li>
        <li>Limpiar vegetales y frutas fumigados (glifosato y otros) con agua, vinagre y bicarbonato.</li>
        <li>Evitar definitivamente los plásticos.</li>
        <li>Evitar las ondas electromagnéticas de las antenas 4G y 5G hacia los celulares; no dejar el celular en la habitación.</li>
      </ul>
    `
  },

  {
    id: "alimentacion-prevencion-2025-11",
    fecha: "2025-11",
    categoria: "Nutrición",
    titulo: "El rol de la alimentación en la prevención de enfermedades",
    autor: "Lourdes Castelli",
    resumen: "Cómo una alimentación saludable, equilibrada y variada nos protege de la obesidad, la diabetes, los problemas cardiovasculares y otras enfermedades.",
    imagen: "Captura de pantalla 2025-11-27 151536.png",
    especialidad: "nutricion",
    contenido: `
      <p>Una alimentación saludable, equilibrada y variada ayuda a protegernos de la malnutrición en todas sus formas, como la obesidad y el sobrepeso, así como de las enfermedades no transmisibles, entre ellas la diabetes, las cardiopatías, el ACV, las enfermedades autoinmunes y el cáncer. Los hábitos alimentarios sanos comienzan en los primeros años de vida con la lactancia materna y en la niñez, lo que favorece el crecimiento sano, mejora el desarrollo cognitivo y previene enfermedades crónicas que impactarán en la salud futura.</p>
      <p>Nombramos algunas: la obesidad y el sobrepeso, promovidos por un entorno que ofrece alimentos hipercalóricos, ultraprocesados con ingredientes artificiales y bebidas azucaradas, sumado al estrés y al sedentarismo. La diabetes, que cada año aumenta a nivel mundial, favorecida por la alimentación occidental rica en azúcares y grasas, que aumenta la inflamación del cuerpo y produce daños en diferentes órganos. El ACV y las enfermedades cardiovasculares, también por el alto consumo de calorías, azúcares y ultraprocesados, grasas perjudiciales y snacks, productos con alto contenido de sal, fiambres y embutidos. Y por último el cáncer, especialmente el de colon, asociado a malos hábitos alimentarios, sobre todo al consumo de productos ultraprocesados.</p>
      <p>Así, cada uno de nosotros puede comprometerse con su propia salud consumiendo alimentos variados y naturales, ricos en vitaminas y minerales, proteínas animales y vegetales de buena calidad y grasas saludables.</p>

      <h3>Qué incluir en tu alimentación</h3>
      <ul>
        <li>Vegetales crudos y cocidos, variando los colores: al menos medio plato al día.</li>
        <li>Frutas enteras y cereales.</li>
        <li>Carnes magras y pescados.</li>
        <li>Legumbres, como lentejas y arvejas.</li>
        <li>Frutos secos, como almendras y nueces.</li>
        <li>Harinas integrales, de legumbres o de avena, evitando las refinadas como la de trigo.</li>
        <li>Aceites de buena calidad, como oliva o uva, y alimentos como palta y aceitunas.</li>
        <li>Agua: al menos 2 litros al día.</li>
      </ul>
      <p>Y, por supuesto, acompañarlo de actividad física regular y de actividades recreativas, meditación, yoga u otras que disminuyan el nivel de estrés.</p>
      <p><em>Escrito por Lourdes Castelli.</em></p>
    `
  },

  {
    id: "que-es-la-psicopedagogia-2025-11",
    fecha: "2025-11",
    categoria: "Psicopedagogía",
    titulo: "¿Qué es la psicopedagogía y en qué áreas interviene?",
    autor: "Franca Podda",
    resumen: "La psicopedagogía no se reduce a lo escolar: repasamos sus áreas de trabajo clínica, educativa, preventiva, laboral y comunitaria.",
    imagen: "",
    especialidad: "psicopedagogia",
    contenido: `
      <p>Muchas veces, como terapeutas, nos enfrentamos a preguntas que aparecen enseguida en un primer encuentro con los padres, respecto a qué es la psicopedagogía, reduciéndola a lo escolar. Esto genera la necesidad de abrir el panorama de aquella idea inicial que vincula al profesional en relación directa y unidireccional con la institución educativa, para dar mayor información. A partir de esto, es interesante poder compartir información para esclarecer lo que para muchos implica un área.</p>
      <p>La psicopedagogía es una disciplina que estudia los procesos de aprendizaje a lo largo de toda la vida, donde se integran aportes de la psicología, las ciencias de la educación, la neurocognición y el campo social. Su intervención abarca múltiples áreas que permiten comprender, orientar y acompañar las trayectorias educativas y el desarrollo integral de las personas. Para una mejor comprensión, es importante detallar las áreas.</p>

      <h3>Área clínica</h3>
      <p>Aquí, el psicopedagogo trabaja con niños, adolescentes y adultos que presentan dificultades en los procesos de aprendizaje. Las principales acciones incluyen:</p>
      <ul>
        <li>Evaluación diagnóstica psicopedagógica.</li>
        <li>Detección de dificultades específicas del aprendizaje y del desarrollo.</li>
        <li>Acompañamientos individualizados para fortalecer habilidades cognitivas, emocionales y socioeducativas.</li>
        <li>Diseño de estrategias que favorezcan la autonomía y el acceso al conocimiento.</li>
      </ul>

      <h3>Área educativa o escolar</h3>
      <p>Está centrada en el acompañamiento de instituciones educativas, docentes, directivos y estudiantes. Aquí se incluye:</p>
      <ul>
        <li>Asesoramiento en prácticas pedagógicas inclusivas.</li>
        <li>Acompañamiento de trayectorias escolares.</li>
        <li>Articulación con equipos de orientación escolar.</li>
        <li>Diseño de estrategias de apoyo y adecuaciones para estudiantes con necesidades específicas.</li>
        <li>Sensibilización y capacitación docente.</li>
      </ul>

      <h3>Área preventiva</h3>
      <p>Busca anticipar dificultades en el aprendizaje y promover condiciones saludables para el desarrollo. Las intervenciones pueden ser:</p>
      <ul>
        <li>Talleres de habilidades sociales, hábitos de estudio y estrategias de aprendizaje.</li>
        <li>Programas de estimulación temprana y fortalecimiento de funciones cognitivas.</li>
        <li>Trabajo con familias para favorecer entornos de crianza y estudio adecuados.</li>
        <li>Acciones comunitarias que promuevan la inclusión educativa.</li>
      </ul>

      <h3>Área laboral y organizacional</h3>
      <p>Desde esta área se reconoce que el aprendizaje es continuo a lo largo de la vida y que también ocurre en contextos laborales. Las intervenciones incluyen:</p>
      <ul>
        <li>Evaluación de competencias y estilos de aprendizaje.</li>
        <li>Orientación vocacional y ocupacional.</li>
        <li>Desarrollo de habilidades socioemocionales.</li>
        <li>Acompañamiento en procesos de capacitación y formación continua.</li>
      </ul>

      <h3>Área comunitaria y social</h3>
      <p>Se busca comprender los factores culturales y sociales que influyen en el aprendizaje. Esto incluye:</p>
      <ul>
        <li>Trabajo en redes con organizaciones sociales, centros comunitarios y organismos públicos.</li>
        <li>Proyectos socioeducativos.</li>
        <li>Promoción del derecho a la educación y a la accesibilidad.</li>
        <li>Intervenciones en comunidades vulneradas para favorecer condiciones de aprendizaje equitativas.</li>
      </ul>
      <p><em>Escrito por Franca Podda.</em></p>
    `
  }

];
