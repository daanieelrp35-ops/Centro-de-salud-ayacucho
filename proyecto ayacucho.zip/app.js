/* =====================================================================
   APP · navegación y vistas
   No hace falta editar este archivo para actualizar la información.
   Los datos están en js/datos.js y js/blog-datos.js
   ===================================================================== */
(function () {
  "use strict";

  const main = document.getElementById("contenido");
  const pie = document.getElementById("pie");

  /* ---------- Utilidades ---------- */
  const MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio",
    "agosto", "septiembre", "octubre", "noviembre", "diciembre"];

  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  const digitos = (t) => String(t).replace(/\D/g, "");
  const sinAcentos = (s) => String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const listaY = (a) => a.length <= 1 ? a.join("") : a.slice(0, -1).join(", ") + " y " + a[a.length - 1];

  const linkTel = (t) => "tel:" + digitos(t);
  const linkWa = (t, msg) => "https://wa.me/549" + digitos(t) + (msg ? "?text=" + encodeURIComponent(msg) : "");
  const urlImg = (f) => f ? CENTRO.imgBase + encodeURI(f) : "";

  const iniciales = (n) => {
    const p = String(n).split(/\s+/).filter(Boolean);
    return ((p[0] || "")[0] || "") + ((p.length > 1 ? p[p.length - 1] : "")[0] || "");
  };

  function fechaLarga(f) {
    const [a, m, d] = String(f).split("-").map(Number);
    return d ? `${d} de ${MESES[m - 1]} de ${a}` : `${cap(MESES[m - 1])} de ${a}`;
  }
  const claveMes = (f) => String(f).slice(0, 7);
  const etiquetaMes = (k) => { const [a, m] = k.split("-").map(Number); return `${cap(MESES[m - 1])} ${a}`; };

  const POSTS = (typeof BLOG_POSTS !== "undefined" ? BLOG_POSTS : []).slice()
    .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
  const espPorId = (id) => ESPECIALIDADES.find((e) => e.id === id);

  /* Si una imagen no carga: la foto de profesional se cambia por iniciales
     y las demás simplemente se quitan, para que nunca quede un hueco roto. */
  document.addEventListener("error", (ev) => {
    const im = ev.target;
    if (!(im instanceof HTMLImageElement)) return;
    if (im.dataset.avatar !== undefined) {
      const d = document.createElement("div");
      d.className = "avatar";
      d.setAttribute("aria-hidden", "true");
      d.textContent = im.dataset.avatar;
      im.replaceWith(d);
    } else if (im.hasAttribute("data-quitar")) {
      (im.closest("[data-quitable]") || im).remove();
    }
  }, true);

  /* ---------- Piezas reutilizables ---------- */
  function filaEspecialidad(e) {
    const nombres = e.profesionales.map((p) => p.nombre);
    const texto = sinAcentos([e.nombre, e.resumen || "", ...nombres,
      ...e.profesionales.flatMap((p) => [...(p.especialidades || []), ...(p.cursos || [])])].join(" "));
    return `
      <li class="fila" data-texto="${esc(texto)}">
        <div class="puerta c-${esc(e.color)}" aria-hidden="true">${e.emoji}</div>
        <div class="fila__texto">
          <h3>${esc(e.nombre)}</h3>
          <p>${esc(listaY(nombres))}</p>
        </div>
        <a class="boton boton--claro" href="#/especialidad/${esc(e.id)}">Ver datos y horarios<span class="sr-only"> de ${esc(e.nombre)}</span></a>
      </li>`;
  }

  function directorio() {
    return `
      <div class="buscador no-imprimir">
        <label for="buscar">Buscar por especialidad, profesional o tema</label>
        <input id="buscar" type="search" placeholder="Por ejemplo: pediatra, diabetes, ortodoncia" autocomplete="off">
      </div>
      <ul class="directorio" id="directorio">${ESPECIALIDADES.map(filaEspecialidad).join("")}</ul>
      <p class="vacio" id="sin-resultados" hidden>No encontramos coincidencias. Probá con otra palabra.</p>`;
  }

  function activarBuscador() {
    const inp = document.getElementById("buscar");
    if (!inp) return;
    inp.addEventListener("input", () => {
      const q = sinAcentos(inp.value.trim());
      let visibles = 0;
      document.querySelectorAll("#directorio .fila").forEach((li) => {
        const ok = !q || li.dataset.texto.includes(q);
        li.hidden = !ok;
        if (ok) visibles++;
      });
      document.getElementById("sin-resultados").hidden = visibles > 0;
    });
  }

  function tarjetaNota(p) {
    return `
      <article class="nota">
        ${p.imagen ? `<a class="nota__img" data-quitable href="#/blog/${esc(p.id)}" tabindex="-1" aria-hidden="true"><img src="${esc(urlImg(p.imagen))}" alt="" loading="lazy" data-quitar></a>` : ""}
        <div class="nota__texto">
          <p class="meta"><span class="etiqueta">${esc(p.categoria)}</span><time datetime="${esc(p.fecha)}">${esc(fechaLarga(p.fecha))}</time></p>
          <h3><a href="#/blog/${esc(p.id)}">${esc(p.titulo)}</a></h3>
          <p>${esc(p.resumen)}</p>
          ${p.autor ? `<p class="autor">Por ${esc(p.autor)}</p>` : ""}
        </div>
      </article>`;
  }

  function galeria(archivos, alt) {
    const items = (archivos || []).map((f) =>
      `<figure data-quitable><img src="${esc(urlImg(f))}" alt="${esc(alt)}" loading="lazy" data-quitar></figure>`).join("");
    return items ? `<div class="galeria">${items}</div>` : "";
  }

  /* ---------- Vista: Inicio ---------- */
  function vistaInicio() {
    const ultimas = POSTS.slice(0, 3);
    const c = CENTRO;
    return {
      titulo: "", nav: "inicio", despues: activarBuscador,
      html: `
      <section class="hero contenedor">
        <div class="hero__texto">
          <h1>Cuidamos de vos y de quienes más querés.</h1>
          <p class="hero__bajada">Somos un equipo con experiencia en barrio Ayacucho. Elegí una especialidad para ver quién atiende, en qué horarios y cómo pedir tu turno.</p>
          <div class="acciones">
            <a class="boton" href="#/especialidades">Ver especialidades</a>
            <a class="boton boton--linea" href="#/blog">Leer el blog</a>
          </div>
        </div>
        <figure class="hero__foto" data-quitable>
          <img src="${esc(urlImg(c.imagenes.hero))}" alt="${esc(c.consultorios.nombre)}" data-quitar>
          <figcaption class="cartel">
            <strong>${esc(c.consultorios.nombre)}</strong>
            <span>${esc(c.consultorios.zona)}</span>
          </figcaption>
        </figure>
      </section>

      <section class="seccion contenedor" aria-labelledby="t-esp">
        <h2 id="t-esp">Nuestras especialidades</h2>
        <p class="bajada">Entrá a cada una para ver los datos del profesional, los horarios, los turnos y el teléfono.</p>
        ${directorio()}
      </section>

      <section class="seccion contenedor" aria-labelledby="t-blog">
        <h2 id="t-blog">Lo último del blog</h2>
        <p class="bajada">Información de nuestros profesionales para cuidarte mejor. Sumamos notas nuevas todos los meses.</p>
        ${ultimas.length ? ultimas.map(tarjetaNota).join("") : `<p class="vacio">Pronto vamos a publicar la primera nota.</p>`}
        <p class="mas"><a class="boton boton--claro" href="#/blog">Ver todas las notas</a></p>
      </section>

      <section class="banda banda--sol" aria-labelledby="t-farm">
        <div class="contenedor banda__in">
          <div>
            <h2 id="t-farm">${esc(c.farmacia.nombre)}: descuento después de tu consulta</h2>
            <p>Llevando tu recetario de nuestros consultorios, abonando en efectivo, tenés un descuento especial. Con envío a domicilio y atención personalizada.</p>
          </div>
          <div class="acciones">
            <a class="boton boton--oscuro" href="#/farmacia">Ver horarios y datos</a>
          </div>
        </div>
      </section>

      <section class="seccion contenedor historia" aria-labelledby="t-hist">
        <div>
          <h2 id="t-hist">Nuestra historia</h2>
          <p>Hace más de 30 años abrimos las puertas de nuestro consultorio con un sueño. Desde entonces nuestro propósito es cuidar con respeto y dedicación la salud de las personas.</p>
          <p>Con el paso del tiempo hemos crecido, incorporando nuevas especialidades y profesionales que comparten la misma vocación y ofrecen una atención integral y de calidad.</p>
        </div>
        ${galeria(c.imagenes.consultorios, c.consultorios.nombre)}
      </section>`
    };
  }

  /* ---------- Vista: Especialidades ---------- */
  function vistaEspecialidades() {
    return {
      titulo: "Especialidades", nav: "especialidades", despues: activarBuscador,
      html: `
      <section class="contenedor seccion seccion--cab">
        <h1>Especialidades</h1>
        <p class="bajada">Estas son las especialidades con las que contamos en ${esc(CENTRO.consultorios.nombre)}. Entrá a cada una para ver el profesional que atiende, horarios, turnos y teléfono.</p>
        ${directorio()}
      </section>`
    };
  }

  /* ---------- Vista: una especialidad ---------- */
  function bloqueLista(titulo, items) {
    if (!items || !items.length) return "";
    return `<section class="bloque"><h3>${esc(titulo)}</h3><ul class="lista">${items.map((i) => `<li>${esc(i)}</li>`).join("")}</ul></section>`;
  }

  function bloqueHorarios(p) {
    const h = p.horarios || [];
    const tabla = h.length ? `
      <table class="tabla">
        <caption class="sr-only">Días y horarios de atención de ${esc(p.nombre)}</caption>
        <tbody>${h.map((x) => `
          <tr>
            <th scope="row">${esc(x.dias)}</th>
            <td>${esc(x.horas)}${x.nota ? `<small>${esc(x.nota)}</small>` : ""}</td>
          </tr>`).join("")}
        </tbody>
      </table>` : `<p class="vacio">Días y horarios: consultar al pedir el turno.</p>`;
    return `<section class="bloque"><h3>Días y horarios</h3>${tabla}</section>`;
  }

  function bloqueContacto(p, e) {
    const numWa = p.whatsapp || p.telefono;
    const msg = `Hola, quisiera pedir un turno en ${e.nombre} con ${p.nombre}.`;
    const turnos = p.turnos || `Para pedir turno comunicate por teléfono o WhatsApp al ${p.telefono}.`;
    return `
      <section class="bloque">
        <h3>Turnos y contacto</h3>
        <p>${esc(turnos)}</p>
        <div class="contacto">
          <a class="boton" href="${esc(linkTel(p.telefono))}">Llamar al ${esc(p.telefono)}</a>
          <a class="boton boton--wa" href="${esc(linkWa(numWa, msg))}" target="_blank" rel="noopener">Pedir turno por WhatsApp<span class="sr-only"> (se abre en otra pestaña)</span></a>
        </div>
      </section>`;
  }

  function bloqueDatos(p) {
    const cs = CENTRO.consultorios;
    const lugar = [cs.nombre, cs.zona, cs.direccion].filter(Boolean).join(", ");
    const os = (p.obrasSociales || []).length ? p.obrasSociales.join(", ") : "Consultar al pedir el turno";
    const redes = Object.entries(p.redes || {}).filter(([, v]) => v)
      .map(([k, v]) => `<a href="${esc(v)}" target="_blank" rel="noopener">${esc(cap(k))}</a>`).join(", ");
    return `
      <section class="bloque">
        <h3>Datos de atención</h3>
        <dl class="datos">
          <dt>Lugar</dt><dd>${esc(lugar)}${cs.mapa ? ` <a href="${esc(cs.mapa)}" target="_blank" rel="noopener">Cómo llegar</a>` : ""}</dd>
          ${p.modalidad ? `<dt>Modalidad</dt><dd>${esc(p.modalidad)}</dd>` : ""}
          <dt>Obras sociales</dt><dd>${esc(os)}</dd>
          ${p.notas ? `<dt>Importante</dt><dd>${esc(p.notas)}</dd>` : ""}
          ${redes ? `<dt>Redes y web</dt><dd>${redes}</dd>` : ""}
        </dl>
      </section>`;
  }

  function fichaProfesional(p, e) {
    const ini = iniciales(p.nombre);
    const retrato = p.foto
      ? `<img class="foto" src="${esc(urlImg(p.foto))}" alt="Foto de ${esc(p.nombre)}" width="120" height="150" loading="lazy" data-avatar="${esc(ini)}">`
      : `<div class="avatar" aria-hidden="true">${esc(ini)}</div>`;
    return `
      <article class="prof c-${esc(e.color)}">
        <header class="prof__cab">
          ${retrato}
          <div>
            <h2>${esc(p.nombre)}</h2>
            ${p.matricula ? `<p class="chapa">Matrícula ${esc(p.matricula)}</p>` : ""}
            ${p.frase ? `<p class="frase">“${esc(p.frase)}”</p>` : ""}
          </div>
        </header>
        <div class="prof__cuerpo">
          <div class="col">
            ${bloqueContacto(p, e)}
            ${bloqueHorarios(p)}
          </div>
          <div class="col">
            ${bloqueLista("Especialidades", p.especialidades)}
            ${bloqueLista("Formación y áreas de trabajo", p.cursos)}
            ${bloqueDatos(p)}
          </div>
        </div>
      </article>`;
  }

  function vistaEspecialidad(id) {
    const e = espPorId(id);
    if (!e) return vista404();
    const otras = ESPECIALIDADES.filter((x) => x.id !== e.id);
    const notas = POSTS.filter((p) => p.especialidad === e.id);
    const n = e.profesionales.length;
    return {
      titulo: e.nombre, nav: "especialidades",
      html: `
      <section class="cab-esp c-${esc(e.color)}">
        <div class="contenedor">
          <a class="volver" href="#/especialidades">Volver a especialidades</a>
          <div class="cab-esp__fila">
            <div class="puerta puerta--grande" aria-hidden="true">${e.emoji}</div>
            <div>
              <h1>${esc(e.nombre)}</h1>
              ${e.resumen ? `<p class="cab-esp__resumen">${esc(e.resumen)}</p>` : ""}
              <p class="cab-esp__cant">${n === 1 ? "1 profesional" : n + " profesionales"}</p>
            </div>
          </div>
        </div>
      </section>

      <div class="contenedor esp-layout">
        <div>${e.profesionales.map((p) => fichaProfesional(p, e)).join("")}</div>
        <aside class="lateral no-imprimir">
          ${notas.length ? `
            <h2>En el blog</h2>
            <ul class="lista-link">${notas.map((p) => `<li><a href="#/blog/${esc(p.id)}">${esc(p.titulo)}</a></li>`).join("")}</ul>` : ""}
          <h2>Otras especialidades</h2>
          <ul class="lista-link">${otras.map((o) => `<li><a href="#/especialidad/${esc(o.id)}">${esc(o.nombre)}</a></li>`).join("")}</ul>
        </aside>
      </div>`
    };
  }

  /* ---------- Vista: Blog ---------- */
  let filtro = { cat: "Todas", mes: "todos" };

  function pintarNotas() {
    const cont = document.getElementById("lista-notas");
    if (!cont) return;
    const lista = POSTS.filter((p) =>
      (filtro.cat === "Todas" || p.categoria === filtro.cat) &&
      (filtro.mes === "todos" || claveMes(p.fecha) === filtro.mes));

    if (!lista.length) {
      cont.innerHTML = `<p class="vacio">No hay notas con ese filtro.</p>`;
    } else {
      const grupos = new Map();
      lista.forEach((p) => {
        const k = claveMes(p.fecha);
        if (!grupos.has(k)) grupos.set(k, []);
        grupos.get(k).push(p);
      });
      cont.innerHTML = [...grupos].map(([k, ps]) =>
        `<section aria-label="${esc(etiquetaMes(k))}"><h2 class="mes">${esc(etiquetaMes(k))}</h2>${ps.map(tarjetaNota).join("")}</section>`).join("");
    }
    document.querySelectorAll(".chip").forEach((b) =>
      b.setAttribute("aria-pressed", String(b.dataset.cat === filtro.cat)));
  }

  function vistaBlog() {
    const cats = ["Todas", ...new Set(POSTS.map((p) => p.categoria))];
    const meses = [...new Set(POSTS.map((p) => claveMes(p.fecha)))];
    return {
      titulo: "Blog", nav: "blog",
      html: `
      <section class="contenedor seccion seccion--cab">
        <h1>Blog</h1>
        <p class="bajada">Novedades y notas de nuestros profesionales para que te mantengas informado con datos claros. Sumamos información nueva todos los meses.</p>
        <div class="filtros no-imprimir">
          <div class="chips" role="group" aria-label="Filtrar por tema">
            ${cats.map((c) => `<button type="button" class="chip" data-cat="${esc(c)}" aria-pressed="${c === filtro.cat}">${esc(c)}</button>`).join("")}
          </div>
          <label class="selector">Mes
            <select id="filtro-mes">
              <option value="todos">Todos los meses</option>
              ${meses.map((m) => `<option value="${m}"${m === filtro.mes ? " selected" : ""}>${esc(etiquetaMes(m))}</option>`).join("")}
            </select>
          </label>
        </div>
        <div id="lista-notas" aria-live="polite"></div>
      </section>`,
      despues() {
        pintarNotas();
        document.querySelectorAll(".chip").forEach((b) =>
          b.addEventListener("click", () => { filtro.cat = b.dataset.cat; pintarNotas(); }));
        document.getElementById("filtro-mes").addEventListener("change", (ev) => {
          filtro.mes = ev.target.value; pintarNotas();
        });
      }
    };
  }

  function vistaNota(id) {
    const i = POSTS.findIndex((p) => p.id === id);
    if (i < 0) return vista404();
    const p = POSTS[i];
    const masNueva = POSTS[i - 1], masVieja = POSTS[i + 1];
    const esp = p.especialidad ? espPorId(p.especialidad) : null;
    const url = location.href.split("#")[0] + "#/blog/" + p.id;
    return {
      titulo: p.titulo, nav: "blog",
      despues() {
        const b = document.querySelector("[data-imprimir]");
        if (b) b.addEventListener("click", () => window.print());
      },
      html: `
      <article class="articulo">
        <a class="volver no-imprimir" href="#/blog">Volver al blog</a>
        <p class="meta"><span class="etiqueta">${esc(p.categoria)}</span><time datetime="${esc(p.fecha)}">${esc(fechaLarga(p.fecha))}</time>${p.autor ? `<span>Por ${esc(p.autor)}</span>` : ""}</p>
        <h1>${esc(p.titulo)}</h1>
        ${p.imagen ? `<img class="articulo__img" src="${esc(urlImg(p.imagen))}" alt="" data-quitar>` : ""}
        <div class="texto">${p.contenido}</div>

        <div class="acciones-nota no-imprimir">
          <button type="button" class="boton boton--claro" data-imprimir>Imprimir esta nota</button>
          <a class="boton boton--claro" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(p.titulo + " " + url)}">Compartir por WhatsApp</a>
          ${esp ? `<a class="boton" href="#/especialidad/${esc(esp.id)}">Ver datos de ${esc(esp.nombre)}</a>` : ""}
        </div>

        <nav class="vecinas no-imprimir" aria-label="Otras notas">
          ${masNueva ? `<a href="#/blog/${esc(masNueva.id)}"><small>Nota más reciente</small><strong>${esc(masNueva.titulo)}</strong></a>` : "<span></span>"}
          ${masVieja ? `<a href="#/blog/${esc(masVieja.id)}"><small>Nota anterior</small><strong>${esc(masVieja.titulo)}</strong></a>` : "<span></span>"}
        </nav>
      </article>`
    };
  }

  /* ---------- Vista: Farmacia ---------- */
  function vistaFarmacia() {
    const f = CENTRO.farmacia;
    const fotos = CENTRO.imagenes.farmacia || [];
    const mapa = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(f.direccion);
    const msg = `Hola ${f.atiende}, quisiera consultar por un producto.`;

    const horarios = (f.horarios || []).length ? `
      <section class="bloque">
        <h3>Horarios de atención</h3>
        <table class="tabla">
          <caption class="sr-only">Días y horarios de la ${esc(f.nombre)}</caption>
          <tbody>${f.horarios.map((x) => `
            <tr><th scope="row">${esc(x.dias)}</th><td>${esc(x.horas)}${x.nota ? `<small>${esc(x.nota)}</small>` : ""}</td></tr>`).join("")}
          </tbody>
        </table>
      </section>` : "";

    const servicios = bloqueLista("Beneficios y servicios", f.servicios);

    const datos = `
      <section class="bloque">
        <h3>Datos de contacto</h3>
        <dl class="datos">
          <dt>Dirección</dt><dd>${esc(f.direccion)}</dd>
          ${f.telefono ? `<dt>Teléfono</dt><dd><a href="${esc(linkTel(f.telefono))}">${esc(f.telefono)}</a></dd>` : ""}
          <dt>WhatsApp</dt><dd>${esc(f.whatsapp)} (${esc(f.atiende)})</dd>
          ${(f.convenios || []).length ? `<dt>Convenios</dt><dd>${esc(f.convenios.join(", "))}</dd>` : ""}
          ${f.notas ? `<dt>Importante</dt><dd>${esc(f.notas)}</dd>` : ""}
        </dl>
      </section>`;

    const principal = fotos[0] ? `
      <figure class="farmacia__foto" data-quitable>
        <img src="${esc(urlImg(fotos[0]))}" alt="${esc(f.nombre)}, ${esc(f.direccion)}" data-quitar>
      </figure>` : "";

    return {
      titulo: f.nombre, nav: "farmacia",
      html: `
      <section class="contenedor seccion seccion--cab">
        <div class="farmacia c-lima">
          <div class="farmacia__info">
            ${f.logo ? `<img class="farmacia__logo" src="${esc(urlImg(f.logo))}" alt="Logo de ${esc(f.nombre)}" data-quitar>` : ""}
            <h1>${esc(f.nombre)}</h1>
            <p class="bajada">Después de atenderte con uno de nuestros profesionales, llevando tu recetario, tenés un descuento especial abonando en efectivo.</p>
            <p>Si querés consultar por un producto, escribinos por WhatsApp. Contamos con envío a domicilio y atención personalizada.</p>
            <div class="acciones">
              <a class="boton boton--wa" href="${esc(linkWa(f.whatsapp, msg))}" target="_blank" rel="noopener">Escribir por WhatsApp<span class="sr-only"> (se abre en otra pestaña)</span></a>
              ${f.telefono ? `<a class="boton" href="${esc(linkTel(f.telefono))}">Llamar al ${esc(f.telefono)}</a>` : ""}
              <a class="boton boton--claro" href="${esc(mapa)}" target="_blank" rel="noopener">Cómo llegar<span class="sr-only"> (se abre en otra pestaña)</span></a>
            </div>
            ${horarios}
            ${servicios}
            ${datos}
          </div>
          <div class="farmacia__fotos">
            ${principal}
            ${galeria(fotos.slice(1), f.nombre)}
          </div>
        </div>
      </section>`
    };
  }

  function vista404() {
    return {
      titulo: "No encontrada", nav: "",
      html: `
      <section class="contenedor seccion seccion--cab">
        <h1>No encontramos esa página</h1>
        <p class="bajada">Puede que el enlace haya cambiado. Podés volver al inicio o ver las especialidades.</p>
        <div class="acciones">
          <a class="boton" href="#/">Ir al inicio</a>
          <a class="boton boton--claro" href="#/especialidades">Ver especialidades</a>
        </div>
      </section>`
    };
  }

  /* ---------- Pie de página ---------- */
  function pintarPie() {
    const c = CENTRO, f = c.farmacia, cs = c.consultorios;
    pie.innerHTML = `
      <div class="contenedor pie__in">
        <div>
          <p class="pie__tit">${esc(c.nombre)}</p>
          <p>${esc(c.lema)}</p>
        </div>
        <div>
          <h2 class="pie__sub">Consultorios</h2>
          <p>${esc(cs.nombre)}<br>${esc(cs.zona)}${cs.direccion ? `<br>${esc(cs.direccion)}` : ""}</p>
          <p>Para pedir turno, entrá a la especialidad que necesitás.</p>
        </div>
        <div>
          <h2 class="pie__sub">${esc(f.nombre)}</h2>
          <p>${esc(f.direccion)}<br>WhatsApp <a href="${esc(linkWa(f.whatsapp))}" target="_blank" rel="noopener">${esc(f.whatsapp)}</a>${f.telefono ? `<br>Tel. <a href="${esc(linkTel(f.telefono))}">${esc(f.telefono)}</a>` : ""}</p>
        </div>
      </div>
      <p class="contenedor pie__leg">© ${new Date().getFullYear()} ${esc(c.nombre)}. ${esc(cs.nombre)}, barrio Ayacucho.</p>`;
  }

  /* ---------- Router ---------- */
  function ruta() {
    const partes = location.hash.replace(/^#\/?/, "").split("/");
    return { a: partes[0] || "", b: decodeURIComponent(partes[1] || "") };
  }

  function render(primera) {
    const { a, b } = ruta();
    let v;
    switch (a) {
      case "": v = vistaInicio(); break;
      case "especialidades": v = vistaEspecialidades(); break;
      case "especialidad": v = vistaEspecialidad(b); break;
      case "blog": v = b ? vistaNota(b) : vistaBlog(); break;
      case "farmacia": v = vistaFarmacia(); break;
      default: v = vista404();
    }
    main.innerHTML = v.html;
    document.title = v.titulo ? `${v.titulo} | ${CENTRO.nombre}` : CENTRO.nombre;
    document.querySelectorAll(".nav a").forEach((l) => {
      if (l.dataset.nav === v.nav) l.setAttribute("aria-current", "page");
      else l.removeAttribute("aria-current");
    });
    if (v.despues) v.despues();
    if (!primera) {
      window.scrollTo(0, 0);
      main.focus({ preventScroll: true });
    }
  }

  document.querySelector(".saltar").addEventListener("click", (ev) => {
    ev.preventDefault();
    main.focus();
  });

  window.addEventListener("hashchange", () => render(false));
  pintarPie();
  render(true);
})();
