/* =====================================================================
   DATOS DEL CENTRO, ESPECIALIDADES Y PROFESIONALES
   ---------------------------------------------------------------------
   Este es el archivo que se edita para mantener la información al día.
   No hace falta tocar nada más para cambiar teléfonos, horarios, etc.

   REGLAS BÁSICAS
   - Cada texto va entre comillas "así".
   - Cada elemento de una lista termina con coma.
   - Si un dato no existe, dejalo vacío ("" o []) y la página lo maneja sola.

   PLANTILLA DE UN PROFESIONAL (copiala dentro de "profesionales")
   ---------------------------------------------------------------------
   {
     nombre: "Nombre Apellido",
     matricula: "1234",
     telefono: "351 1234567",              // se usa para "Llamar" y "WhatsApp"
     whatsapp: "",                         // solo si es distinto del teléfono
     foto: "nombre-del-archivo.jpg",       // archivo de imagen (opcional)
     frase: "",                            // frase de presentación (opcional)
     especialidades: ["Ortodoncia", "Odontopediatría"],
     cursos: ["Curso o experiencia destacada"],
     modalidad: "Presencial y online",     // opcional
     obrasSociales: ["OSDE", "Swiss Medical", "Particulares"],
     horarios: [
       { dias: "Lunes y miércoles", horas: "16:00 a 20:00" },
       { dias: "Viernes",           horas: "09:00 a 12:00", nota: "Solo con turno previo" }
     ],
     turnos: "Turnos por WhatsApp de lunes a viernes de 9 a 18 h.",
     notas: "Cualquier aviso importante (opcional).",
     redes: { instagram: "https://instagram.com/usuario", facebook: "", web: "" }
   }
   ===================================================================== */

const CENTRO = {
  nombre: "Grupo Salud Integral Ayacucho",
  lema: "Acompañándote desde lo profesional hace más de 30 años",

  /* De dónde se cargan las fotos. Si copiás las imágenes dentro de esta
     misma carpeta del proyecto (por ejemplo en /img/), cambialo por "img/". */
  imgBase: "https://grupo-salud-integral-ayacucho.github.io/oficial/",

  imagenes: {
    hero: "Imagen de WhatsApp 2025-10-07 a las 11.15.13_68636b57.jpg",
    consultorios: [
      "Imagen de WhatsApp 2025-10-07 a las 11.15.13_68636b57.jpg",
      "Imagen de WhatsApp 2025-10-07 a las 11.15.14_61c2ecd6.jpg"
    ],
    farmacia: [
      "Imagen de WhatsApp 2025-10-07 a las 11.15.14_4919e7c8.jpg",
      "Imagen de WhatsApp 2025-10-07 a las 11.15.14_5b65670a.jpg",
      "WhatsApp Image 2026-08-07 at 14.22.08.jpeg",
      "WhatsApp Image 2026-08-07 at 14.22.09.jpeg"
    ]
  },

  consultorios: {
    nombre: "Consultorios Capdevilla",
    zona: "Barrio Ayacucho, Córdoba",
    direccion: "",   // completar: calle y número
    mapa: ""         // opcional: link de Google Maps
  },

  /* Farmacia Cruz Verde.
     Horarios, teléfono fijo y convenio: tomados de directorios públicos
     (APROSS y FarmaciasPAMI). Confirmalos con la farmacia antes de publicar. */
  farmacia: {
    nombre: "Farmacia Cruz Verde",
    atiende: "Daniel",
    whatsapp: "351 3580435",
    telefono: "351 4781375",
    direccion: "Los Ticas 2409, barrio Centroamérica, Córdoba",
    horarios: [
      { dias: "Lunes a viernes", horas: "9:00 a 20:00" },
      { dias: "Sábados",         horas: "9:00 a 15:00" }
    ],
    servicios: [
      "Descuento especial con el recetario de nuestros consultorios, abonando en efectivo",
      "Envío a domicilio",
      "Atención personalizada",
      "Consulta de productos por WhatsApp"
    ],
    convenios: ["PAMI"],
    logo: "",   // opcional: nombre del archivo del logo de Cruz Verde (ej: "logo-cruz-verde.png")
    notas: ""   // opcional: avisos (feriados, turnos, etc.)
  }
};

/* Colores disponibles: menta, sol, lila, cielo, rosa, durazno, lima, piedra */
const ESPECIALIDADES = [
  {
    id: "fonoaudiologia",
    nombre: "Fonoaudiología",
    emoji: "🗣️",
    color: "cielo",
    resumen: "",
    profesionales: [
      {
        nombre: "Sandra Adriana Liebl",
        matricula: "8919",
        telefono: "351 2255030",
        foto: "Captura de pantalla 2025-11-27 150854.png",
        especialidades: [],
        cursos: [
          "Especialidad en Odontoestomatología y en lenguaje y habla",
          "Ingresos escolares"
        ],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      },
      {
        nombre: "Nancy Diaz",
        matricula: "8330",
        telefono: "351 7624907",
        foto: "",
        especialidades: [],
        cursos: [
          "Dislalias", "ACV", "Audiometrías",
          "Neurorrehabilitación", "Informes escolares", "Discapacidad"
        ],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  },

  {
    id: "ninez",
    nombre: "Niñez y adolescencia",
    emoji: "🧒",
    color: "sol",
    resumen: "",
    profesionales: [
      {
        nombre: "Efraín Bustos",
        matricula: "MP 7376, ME 2219",
        telefono: "351 5474055",
        foto: "Captura de pantalla 2025-11-27 150724.png",
        especialidades: [
          "Médico cirujano", "Pediatra", "Magíster en salud pública",
          "Urgencias pediátricas", "Toxicología"
        ],
        cursos: [
          "Tesina sobre convulsiones febriles en atención primaria de la salud (APS)",
          "Experiencia en vías respiratorias y digestivas en hospitales de CABA y Córdoba",
          "Ex jefe de guardia y ex subdirector del Hospital de Niños de Córdoba"
        ],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  },

  {
    id: "psicologia",
    nombre: "Psicología",
    emoji: "🧠",
    color: "lila",
    resumen: "",
    profesionales: [
      {
        nombre: "Romina Mansilla",
        matricula: "9674",
        telefono: "351 5749183",
        foto: "",
        especialidades: [], cursos: [],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  },

  {
    id: "psicopedagogia",
    nombre: "Psicopedagogía",
    emoji: "🧩",
    color: "rosa",
    resumen: "",
    profesionales: [
      {
        nombre: "Franca Podda",
        matricula: "12-4277",
        telefono: "351 5380197",
        foto: "Captura de pantalla 2025-11-27 150747.png",
        especialidades: [],
        cursos: ["Técnica en discapacidad intelectual y estimulación temprana"],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  },

  {
    id: "medicina-generalista",
    nombre: "Medicina generalista",
    emoji: "🩺",
    color: "menta",
    resumen: "La fitoterapia es una rama de la medicina que utiliza plantas medicinales y sus derivados (extractos, infusiones, cápsulas o aceites) para prevenir, aliviar o curar enfermedades.",
    profesionales: [
      {
        nombre: "Stella Cruceño",
        matricula: "34672",
        telefono: "351 7691026",
        foto: "Captura de pantalla 2025-11-27 150927.png",
        especialidades: [],
        cursos: ["Experiencia en clínica médica", "Medicina herbal y fitoterapia"],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  },

  {
    id: "kinesiologia",
    nombre: "Kinesiología y fisioterapia",
    emoji: "💪",
    color: "durazno",
    resumen: "",
    profesionales: [
      {
        nombre: "Bibiana Carlasara",
        matricula: "1081",
        telefono: "351 6631713",
        foto: "Captura de pantalla 2025-11-27 150646.png",
        especialidades: [],
        cursos: [
          "Lesiones deportivas y drenaje linfático",
          "Tratamientos de columna vertebral",
          "Rehabilitación en posoperatorio",
          "Aparatología",
          "Ejercicios posturales"
        ],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  },

  {
    id: "nutricion",
    nombre: "Nutrición",
    emoji: "🥗",
    color: "lima",
    resumen: "Abordaje integral funcional y personalizado, acorde a tus necesidades y tu contexto.",
    profesionales: [
      {
        nombre: "María Lourdes Castelli",
        matricula: "2170",
        telefono: "351 3342559",
        foto: "",
        especialidades: ["Patologías digestivas", "Sobrepeso y obesidad", "Diabetes"],
        cursos: ["Abordaje integral personalizado, para adultos y niños"],
        modalidad: "Presencial y online",
        horarios: [], turnos: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  },

  {
    id: "analisis-clinicos",
    nombre: "Análisis clínicos",
    emoji: "🧪",
    color: "piedra",
    resumen: "",
    profesionales: [
      {
        nombre: "María Virginia Redondo",
        matricula: "4954",
        telefono: "351 3486991",
        foto: "",
        especialidades: [],
        cursos: ["Bioquímica clínica"],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  },

  {
    id: "odontologia",
    nombre: "Odontología",
    emoji: "🦷",
    color: "cielo",
    resumen: "",
    profesionales: [
      {
        nombre: "Melisa Alejandra Solano Caminos",
        matricula: "10952",
        telefono: "351 2258660",
        foto: "WhatsApp Image 2026-08-03 at 11.50.36.jpeg",
        especialidades: ["Ortodoncia y ortopedia", "Odontopediatría", "Armonización facial"],
        cursos: [],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  },

  {
    id: "educacion-especial",
    nombre: "Educación especial",
    emoji: "🤟",
    color: "lila",
    resumen: "",
    profesionales: [
      {
        nombre: "María Florencia Villavicencio",
        matricula: "",
        telefono: "351 6971950",
        foto: "WhatsApp Image 2026-08-03 at 11.51.00.jpeg",
        especialidades: ["Profesora de Educación Especial con orientación en Sordos e Hipoacúsicos"],
        cursos: ["Inclusión educativa", "Apoyo escolar", "Rehabilitación del lenguaje"],
        horarios: [], turnos: "", modalidad: "", obrasSociales: [], notas: "", frase: "", redes: {}
      }
    ]
  }
];
